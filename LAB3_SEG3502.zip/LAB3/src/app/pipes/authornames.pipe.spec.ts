import { AuthornamesPipe } from './authornames.pipe';

describe('AuthornamesPipe', () => {
  it('create an instance', () => {
    const pipe = new AuthornamesPipe();
    expect(pipe).toBeTruthy();
  });
});
